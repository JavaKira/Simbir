package com.github.javakira.simbir.account;

public enum Role {
    user, admin
}
