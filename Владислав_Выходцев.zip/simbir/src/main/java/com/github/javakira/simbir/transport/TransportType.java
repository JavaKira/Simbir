package com.github.javakira.simbir.transport;

public enum TransportType {
    Car, Bike, Scooter, Panzer
}
